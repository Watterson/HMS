@extends('templates.admin')
@section('main')
<div class="row">
    <div class="col-lg-8 offset-lg-2">

        <div class="card">
            <div class="card-header">
                <strong>Oops</strong>
            </div>
            <div class="card-block">

                <div class="alert alert-danger" role="alert">
                  <strong>Oh snap!</strong> Change a few things up and try submitting again.
                </div>

            </div>
 
        </div>
    </div>
</div>

@endsection
