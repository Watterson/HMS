<div class="sidebar" id="sidebar">
      <nav class="sidebar-nav">
        <ul class="nav">
          <li class="nav-item">
            <a class="nav-link" href="{{ url('doctor/')}}"><i class="icon-speedometer"></i> Dashboard <span class="badge badge-primary">NEW</span></a>
          </li>

          <li class="nav-title">
             <i class="icon-people"></i>
          </li>
          <li class="nav-item ">
            <a class="nav-link nav-dropdown-toggle" href="{{ url('doctor/patients')}}"><i class="icon-note"></i> Patients</a>
          </li>
          <li class="nav-item ">
            <a class="nav-link nav-dropdown-toggle" href="#"><i class="icon-star"></i> Appointments</a>
          </li>

          <li class="nav-item nav-dropdown">
            <a class="nav-link nav-dropdown-toggle" href="#"><i class="icon-star"></i> Labs</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="widgets.html"><i class="icon-calculator"></i> Working Hours</a>
          </li>
        </ul>
      </nav>
      <button class="sidebar-minimizer brand-minimizer" type="button"></button>
    </div>
