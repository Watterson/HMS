<?php $__env->startSection('main'); ?>
<div class="row">
    <div class="col-lg-8 offset-lg-2">
        <a href="<?php echo e(url('admin/patients')); ?>" >< Return </a>

        <div class="card">
            <div class="card-header">
                <strong>Add Account</strong>
            </div>
            <div class="card-block">
                <?php echo Form::open(['url'=>'admin/patients/add','class'=>'']); ?>


                <div class="form-group <?php if($errors->first('name')): ?> has-danger <?php endif; ?>">
                    <label class="control-label">Name</label>
                    <div class="controls">
                        <?php echo Form::text('name',null,['class'=>'form-control']); ?>


                        <?php if($errors->first('name')): ?>
                            <div class="form-control-feedback"><?php echo e($errors->first('name')); ?></div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="form-group <?php if($errors->first('email')): ?> has-danger <?php endif; ?>">
                    <label class="control-label">Email (login)</label>
                    <div class="controls">
                        <?php echo Form::text('email',null,['class'=>'form-control']); ?>


                        <?php if($errors->first('email')): ?>
                            <div class="form-control-feedback"><?php echo e($errors->first('email')); ?></div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="form-group <?php if($errors->first('password')): ?> has-danger <?php endif; ?>">
                    <label class="control-label">Password</label>
                    <div class="controls">
                        <?php echo Form::password('password',['class'=>'form-control']); ?>


                        <?php if($errors->first('password')): ?>
                            <div class="form-control-feedback"><?php echo e($errors->first('password')); ?></div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="form-group <?php if($errors->first('password')): ?> has-danger <?php endif; ?>">
                    <label class="control-label">Password Confirmation</label>
                    <div class="controls">
                        <?php echo Form::password('password_confirmation',['class'=>'form-control']); ?>


                        <?php if($errors->first('password')): ?>
                            <div class="form-control-feedback"><?php echo e($errors->first('password')); ?></div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="form-group <?php if($errors->first('role')): ?> has-danger <?php endif; ?>">
                    <label class="control-label">Role</label>
                    <div class="controls">
                        <?php echo Form::text('role',null, ['class'=>'form-control']); ?>


                        <?php if($errors->first('role')): ?>
                            <div class="form-control-feedback"><?php echo e($errors->first('role')); ?></div>
                        <?php endif; ?>
                    </div>
                </div>


            </div>
            <div class="card-footer">
                <button type="submit" class="btn btn-sm btn-primary"><i class="fa fa-dot-circle-o"></i> Add</button>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>