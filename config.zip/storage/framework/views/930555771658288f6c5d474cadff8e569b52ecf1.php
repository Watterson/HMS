<?php $__env->startSection('main'); ?>
<div class="row mt-4">
    <div class="col-lg-8 offset-lg-2">
        <a href="<?php echo e(url('admin/user')); ?>" >< All Users</a>

        <div class="card">
            <div class="card-header">
                <strong>Add Patient</strong>
            </div>
            <div class="card-block">
                <?php echo Form::open(['url'=>'admin/user/add_patient','class'=>'']); ?>


                <div class="form-group <?php if($errors->first('first_name')): ?> has-danger <?php endif; ?>">
                    <label class="control-label">First Name</label>
                    <div class="controls">
                        <?php echo Form::text('first_name','',['class'=>'form-control']); ?>


                        <?php if($errors->first('first_name')): ?>
                            <div class="form-control-feedback"><?php echo e($errors->first('last_name')); ?></div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="form-group <?php if($errors->first('last_name')): ?> has-danger <?php endif; ?>">
                    <label class="control-label">Last Name</label>
                    <div class="controls">
                        <?php echo Form::text('last_name','',['class'=>'form-control']); ?>


                        <?php if($errors->first('last_name')): ?>
                            <div class="form-control-feedback"><?php echo e($errors->first('last_name')); ?></div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="form-group <?php if($errors->first('email')): ?> has-danger <?php endif; ?>">
                    <label class="control-label">Email (login)</label>
                    <div class="controls">
                        <?php echo Form::text('email','',['class'=>'form-control']); ?>


                        <?php if($errors->first('email')): ?>
                            <div class="form-control-feedback"><?php echo e($errors->first('email')); ?></div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="form-group <?php if($errors->first('password')): ?> has-danger <?php endif; ?>">
                    <label class="control-label">Password</label>
                    <div class="controls">
                        <?php echo Form::password('password',['class'=>'form-control']); ?>


                        <?php if($errors->first('password')): ?>
                            <div class="form-control-feedback"><?php echo e($errors->first('password')); ?></div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="form-group <?php if($errors->first('password')): ?> has-danger <?php endif; ?>">
                    <label class="control-label">Password Confirmation</label>
                    <div class="controls">
                        <?php echo Form::password('password_confirmation',['class'=>'form-control']); ?>


                        <?php if($errors->first('password')): ?>
                            <div class="form-control-feedback"><?php echo e($errors->first('password')); ?></div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="form-group <?php if($errors->first('address')): ?> has-danger <?php endif; ?>">
                    <label class="control-label">Mobile</label>
                    <div class="controls">
                        <?php echo Form::text('address',null, ['class'=>'form-control']); ?>


                        <?php if($errors->first('address')): ?>
                            <div class="form-control-feedback"><?php echo e($errors->first('address')); ?></div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="form-group <?php if($errors->first('mobile')): ?> has-danger <?php endif; ?>">
                    <label class="control-label">Mobile</label>
                    <div class="controls">
                        <?php echo Form::text('mobile',null, ['class'=>'form-control']); ?>


                        <?php if($errors->first('mobile')): ?>
                            <div class="form-control-feedback"><?php echo e($errors->first('mobile')); ?></div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="card-footer text-center">
                <button type="submit" id="btn-save" class="btn btn-sm btn-primary"><i class="fa fa-dot-circle-o"></i> Save</button>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>