<?php $__env->startSection('main'); ?>

<div class="row justify-content-center  mt-4">
    <div class="col-lg-10 ">
        <div class="card">
            <div class="card-header">
              <div class=" row">
                  <div class="col-8">
                      <strong>User Accounts</strong>
                  </div>
                    <div class=" col-2 text-right">
                      <a href="<?php echo e(url('admin/user/add_patient')); ?>" class="btn btn-link" role="button">Add Patient</a>
                    </div>
                    <div class="col-2 text-center">
                      <a href="<?php echo e(url('admin/user/add_doctor')); ?>" class="btn btn-link" role="button">Add Doctor</a>
                    </div>
                </div>
            </div>
            <div class="card-block">
            	<table class="table table-striped">
            		<tr>
                  <th>User ID</th>
            			<th>Email</th>
                  <th>Role</th>
            			<?/*<th></th>*/?>

            		</tr>
            		<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            		<tr>
                  <td><?php echo e($user->id); ?></td>
                  <td><a href="<?php echo e(url('admin/user/edit?user='.$user->id)); ?>"><?php echo e($user->email); ?></td>
                  <td><?php echo e($user->role); ?></td>
            		</tr>
            		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            	</table>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>