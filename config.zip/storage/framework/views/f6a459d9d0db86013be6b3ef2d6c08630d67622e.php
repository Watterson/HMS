<?php $__env->startSection('css_includes'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>


<div class="col-lg-10 offset-lg-1">
    <div class="card">
        <div class="card-header">
          <div class=" row">
              <div class="col-8">
                  <strong>User Accounts</strong>
              </div>
                <div class=" col-2 text-right">
                  <a href="<?php echo e(url('doctor/patients/add')); ?>" class="btn btn-link" role="button">Add Patient</a>
                </div>
            </div>
        </div>
        <div class="card-block">
          <table class="table table-striped">
            <tr>
              <th>Name</th>
              <th>Email</th>
            </tr>
            <?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><a href="<?php echo e(url('doctor/patients/edit?user='.$patient->id)); ?>"><?php echo e($patient->first_name); ?> <?php echo e($patient->last_name); ?></a></td>
              <td><?php echo e($patient->email); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js_includes'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.doctor_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>